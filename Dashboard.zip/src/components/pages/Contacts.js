import React from "react";

const Contacts = () => {
  return <div>contacts</div>;
};

export default Contacts;
