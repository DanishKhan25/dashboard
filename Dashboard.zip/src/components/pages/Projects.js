import React from "react";

const Projects = () => {
  return <div>projects</div>;
};

export default Projects;
