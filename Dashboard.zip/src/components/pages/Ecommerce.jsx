import React from "react";

const Ecommerce = () => {
  return <div>Ecommerce</div>;
};

export default Ecommerce;
