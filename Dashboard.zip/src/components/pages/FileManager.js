import React from "react";

const FileManager = () => {
  return <div>FileManager</div>;
};

export default FileManager;
